<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Ambil nilai dari form
  $name = $_POST['name'];
  $subject = $_POST['subject'];
  $email = $_POST['email'];
  $message = $_POST['message'];

  // Validasi form
  if (empty($name) || empty($subject) || empty($email) || empty($message)) {
    echo "Harap isi semua field form.";
    exit();
  }

  // Konfigurasi pengiriman email
  $toEmail = "rudywindcom@gmail.com"; // Ganti dengan alamat email tujuan
  $fromEmail = $email;
  $fromName = $name;
  $emailSubject = $subject;
  $emailBody = $message;

  // Kirim email menggunakan fungsi mail() dengan SSL
  $headers = "From: $fromName <$fromEmail>\r\n";
  $headers .= "Reply-To: $fromEmail\r\n";
  $headers .= "MIME-Version: 1.0\r\n";
  $headers .= "Content-Type: text/html; charset=utf-8\r\n";
  $options = "-f$fromEmail";
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Centered Card</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 90vh;
      overflow:hidden;
    }
  </style>
</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card">
          <div class="card-header">
            <h5 class="card-title mt-0 mb-0">Status</h5>
          </div>
          <div class="card-body">
            <p class="card-text">
            		<?php  	
            		if (mail($toEmail, $emailSubject,$emailBody,	$headers, $options)) {
            		header("Location: https://rudywind.github.io/me/thanks.html");
            		exit();
            		} else {
            		echo "I apologize, <b>$name</b>. The message you intended to send with the subject <b>$subject</b> to us cannot be delivered.";
            		exit();
            		}
            		?>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>


<?php
}
?>